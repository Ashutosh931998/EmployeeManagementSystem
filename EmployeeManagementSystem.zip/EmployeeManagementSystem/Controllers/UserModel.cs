﻿using System.Security.Claims;

namespace EmployeeManagementSystem.Controllers
{
    internal class UserModel
    {
        public ClaimsIdentity? Username { get; internal set; }
        public ClaimsIdentity? Email { get; internal set; }
    }
}